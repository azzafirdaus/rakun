@extends('admin.layout.sidebar')

@section('sidebar')
    @parent
@stop