<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class HistoriPelanggan extends Model
{
    //
    protected $table = 'histori_pelanggan';
    public $timestamps = false;
        
}
